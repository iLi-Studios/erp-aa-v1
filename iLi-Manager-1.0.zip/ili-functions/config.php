<?php 
//locale
define('MYSQL_SERVEUR', 'localhost');
define('MYSQL_UTILISATEUR', 'root');
define('MYSQL_MOTDEPASSE', '');
define('MYSQL_BASE', 'ilimanager10');
$URL="http://localhost/iLi-Manager-1.0/";
$sytem_title="iLi-Manager1.0";
$copy_right ='2016 &copy; '.$sytem_title.'  By <a href="http://www.ili-studios.tn/" target="new" style="none"> <strong>iLi-Studios</strong> </a>';
$author=
"
<!--
iLi-ERP
Développer par : SAKLY AYOUB
Société	: iLi-Studios SARL
Site : http://www.ili-studios.tn/
-->
";
?>