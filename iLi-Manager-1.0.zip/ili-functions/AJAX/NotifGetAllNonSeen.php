<?php
include"../functions.php";
NotifGetAllNonSeen();
?>