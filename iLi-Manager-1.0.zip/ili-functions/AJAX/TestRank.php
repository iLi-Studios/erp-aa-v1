<?php
include"../functions.php";
TestRank();
?>