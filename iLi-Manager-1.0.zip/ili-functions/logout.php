<?php
include"functions.php";
// fonction deconexion
LogOut();
?>